<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Vehiculo;
use Illuminate\Http\Request;

class VehiculoController extends Controller
{
    public function index()
    {
        return response()->json([
            'data' => Vehiculo::orderBy('placa')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'placa'           => 'required|string|max:20|unique:vehiculos,placa',
            'marca'           => 'required|string|max:60',
            'modelo'          => 'required|string|max:60',
            'anio'            => 'required|integer|min:1990|max:2030',
            'capacidad_cajas' => 'required|integer|min:1',
            'activo'          => 'boolean',
            'notas'           => 'nullable|string',
        ]);

        $vehiculo = Vehiculo::create($validated);

        return response()->json(['data' => $vehiculo, 'message' => 'Vehículo registrado.'], 201);
    }

    public function show(Vehiculo $vehiculo)
    {
        return response()->json(['data' => $vehiculo]);
    }

    public function update(Request $request, Vehiculo $vehiculo)
    {
        $validated = $request->validate([
            'placa'           => "required|string|max:20|unique:vehiculos,placa,{$vehiculo->id}",
            'marca'           => 'required|string|max:60',
            'modelo'          => 'required|string|max:60',
            'anio'            => 'required|integer|min:1990|max:2030',
            'capacidad_cajas' => 'required|integer|min:1',
            'activo'          => 'boolean',
            'notas'           => 'nullable|string',
        ]);

        $vehiculo->update($validated);

        return response()->json(['data' => $vehiculo, 'message' => 'Vehículo actualizado.']);
    }

    public function destroy(Vehiculo $vehiculo)
    {
        if ($vehiculo->rutas()->exists()) {
            return response()->json(['message' => 'El vehículo tiene rutas asignadas.'], 422);
        }

        $vehiculo->delete();

        return response()->json(['message' => 'Vehículo eliminado.']);
    }
}
