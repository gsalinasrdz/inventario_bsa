<?php

use App\Http\Middleware\SecurityHeaders;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        api: __DIR__ . '/../routes/api.php',
        apiPrefix: 'api/v1',
        commands: __DIR__ . '/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        // Middleware para SPA con Sanctum
        $middleware->statefulApi();

        // Append middleware global
        $middleware->append(SecurityHeaders::class);

        // Alias de middleware
        $middleware->alias([
            'role'       => \Spatie\Permission\Middleware\RoleMiddleware::class,
            'permission' => \Spatie\Permission\Middleware\PermissionMiddleware::class,
            'role_or_permission' => \Spatie\Permission\Middleware\RoleOrPermissionMiddleware::class,
        ]);

        // Excluir rutas de CSRF (API usa Sanctum cookies)
        $middleware->validateCsrfTokens(except: [
            'api/*',
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        // Respuesta JSON para rutas API no encontradas
        $exceptions->render(function (NotFoundHttpException $e, Request $request) {
            if ($request->is('api/*')) {
                return response()->json([
                    'success' => false,
                    'error'   => [
                        'code'    => 'NOT_FOUND',
                        'message' => 'El recurso solicitado no existe.',
                    ],
                ], 404);
            }
        });

        // Respuesta para errores de validación
        $exceptions->render(function (\Illuminate\Validation\ValidationException $e, Request $request) {
            if ($request->is('api/*')) {
                return response()->json([
                    'success' => false,
                    'error'   => [
                        'code'    => 'VALIDATION_ERROR',
                        'message' => 'Los datos proporcionados no son válidos.',
                        'details' => $e->errors(),
                    ],
                ], 422);
            }
        });

        // Respuesta para no autenticado
        $exceptions->render(function (\Illuminate\Auth\AuthenticationException $e, Request $request) {
            if ($request->is('api/*')) {
                return response()->json([
                    'success' => false,
                    'error'   => [
                        'code'    => 'UNAUTHENTICATED',
                        'message' => 'No autenticado. Inicie sesión para continuar.',
                    ],
                ], 401);
            }
        });

        // Respuesta para sin permisos
        $exceptions->render(function (\Illuminate\Auth\Access\AuthorizationException $e, Request $request) {
            if ($request->is('api/*')) {
                return response()->json([
                    'success' => false,
                    'error'   => [
                        'code'    => 'FORBIDDEN',
                        'message' => 'No tiene permisos para realizar esta acción.',
                    ],
                ], 403);
            }
        });

        // Stock insuficiente
        $exceptions->render(function (\App\Exceptions\StockInsuficienteException $e, Request $request) {
            return response()->json([
                'success' => false,
                'error'   => [
                    'code'    => 'STOCK_INSUFICIENTE',
                    'message' => $e->getMessage(),
                ],
            ], 422);
        });
    })
    ->create();
